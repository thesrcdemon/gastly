```const { MessageEmbed } = require('discord.js');
module.exports = {
config: {
name: "hi",
aliases: ["pfp"]
},
run: async (client, message, args) => {
const user = client.users.cache.random();
        const embed = new MessageEmbed()   
            .setColor("#B99BF6")
            .setImage(user.displayAvatarURL({ dynamic: true}))
            .setDescription(`**${user.tag}'s avatar**`)
        message.channel.send({ embeds: [embed]})
}
};```